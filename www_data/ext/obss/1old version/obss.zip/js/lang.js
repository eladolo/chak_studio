window.lang = {
	"es":{
		"label_config_save_credentials" : "Guardar datos",
		"label_config_requirements" : "Requerimientos",
		"label_config_requirements_content" : "- Es necesario que instales el siguiente plugin <a href=\"https://obsproject.com/forum/resources/obs-websocket-remote-control-of-obs-studio-made-easy.466/\" target=\"_blank\">OBS websocket</a>.<br>- Tienes que exponer tu OBS sobre <a href=\"https://stackoverflow.com/questions/26791107/wss-on-http-vs-wss-on-https\" target=\"_blank\">SSL</a>.<br>&nbsp; . Debido a que Twitch esta sobre SSL las conecciones planas(ws) no estan permitidas.<br>- Tienes que exponer tu puerto de OBS a una <a href=\"https://stackoverflow.com/questions/4717426/how-to-expose-my-localhost-to-the-www-port-forwarding\" target=\"_blank\">url visible desde internet</a>.<br>- <b>La mejor opcion para un humano normal es <a href=\"https://ngrok.com/\" target=\"_blank\">ngrok.com</a>, ellos ya hicieron facil todo ese procedimiento(y es gratis!!)</b>.<br>",
		"label_config_usage" : "Uso",
		"label_config_usage_content" : "- Usa este panel para guardar tus credenciales.<br>- En tu dashboard de <b>twitch</b> en el panel de extensiones van aparecer:<br>&nbsp; . un boton para iniciar/detener el streaming de OBS.<br>&nbsp; . un boton por cada escena.<br>&nbsp; . un boton para cerrar la coneccion a OBS.<br>- <b>Cuando el stream inicie</b>, en tu dashboard/canal <b>video</b> va estar un overlay con :<br>&nbsp; . un boton para detener el stream de OBS.<br>&nbsp; .  un boton por cada escena.<br>&nbsp; . un boton para cerrar la coneccion a OBS.<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<emp>* Si la extension <b class=\"red-text\">no puede conectarse</b> a OBS, mostrara un login para poder cambiar tus credenciales</emp>.<br>",
		"label_config_feedback_text" : "Feedback",
		"label_config_a_send" : "Enviar",		"label_config_support_text" : "* Si te sirve esta extension tu apoyo es muy bien recibido ",
		"label_obs_error_credential" : "<p>Revisa tus credenciales y prueba de nuevo <b class=\"red-text\">error</b></p>",

		"label_obs_connect"  : "connectar",
		"label_obs_close"  : "cerrar",
		"label_obs_empty"  : "<p>No dejes ningun campo <b class=\"red-text\">vacio</b>!</p>",
		"label_obs_connected" : "<p>OBS <b class=\"green-text\">connectado</b></p>",
		"label_obs_check" : "<p><b class=\"orange-text\">Buscando</b> OBS</p>",
		"label_obs_check_again" : "<p><b class=\"blue-text\">Buscando</b> de nuevo OBS</p>",
		"tooltip_feedback_empty" : "No dejes ningun campo vacio",
		"tooltip_feedback_ok" : "Gracias por tu feedback, lo mas pronto posible antendere tus comentarios.",
		"tooltip_feedback_error" : "Lo siente, pero hubo un error y no se pudo mandar tu feedback en este momento.",
		"tooltip_config_save" : "<p>Configuracion <b class=\"green-text\">guardada</b>!</p>"
	},
	"es-mx":{
		"label_config_save_credentials" : "Guardar datos",
		"label_config_requirements" : "Requerimientos",
		"label_config_requirements_content" : "- Es necesario que instales el siguiente plugin <a href=\"https://obsproject.com/forum/resources/obs-websocket-remote-control-of-obs-studio-made-easy.466/\" target=\"_blank\">OBS websocket</a>.<br>- Tienes que exponer tu OBS sobre <a href=\"https://stackoverflow.com/questions/26791107/wss-on-http-vs-wss-on-https\" target=\"_blank\">SSL</a>.<br>&nbsp; . Debido a que Twitch esta sobre SSL las conecciones planas(ws) no estan permitidas.<br>- Tienes que exponer tu puerto de OBS a una <a href=\"https://stackoverflow.com/questions/4717426/how-to-expose-my-localhost-to-the-www-port-forwarding\" target=\"_blank\">url visible desde internet</a>.<br>- <b>La mejor opcion para un humano normal es <a href=\"https://ngrok.com/\" target=\"_blank\">ngrok.com</a>, ellos ya hicieron facil todo ese procedimiento(y es gratis!!)</b>.<br>",
		"label_config_usage" : "Uso",
		"label_config_usage_content" : "- Usa este panel para guardar tus credenciales.<br>- En tu dashboard de <b>twitch</b> en el panel de extensiones van aparecer:<br>&nbsp; . un boton para iniciar/detener el streaming de OBS.<br>&nbsp; . un boton por cada escena.<br>&nbsp; . un boton para cerrar la coneccion a OBS.<br>- <b>Cuando el stream inicie</b>, en tu dashboard/canal <b>video</b> va estar un overlay con :<br>&nbsp; . un boton para detener el stream de OBS.<br>&nbsp; .  un boton por cada escena.<br>&nbsp; . un boton para cerrar la coneccion a OBS.<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<emp>* Si la extension <b class=\"red-text\">no puede conectarse</b> a OBS, mostrara un login para poder cambiar tus credenciales</emp>.<br>",
		"label_config_feedback_text" : "Feedback",
		"label_config_a_send" : "Enviar",
		"label_config_support_text" : "* Si te sirve esta extension tu apoyo es muy bien recibido ",
		"label_obs_error_credential" : "<p>Revisa tus credenciales y prueba de nuevo <b class=\"red-text\">error</b></p>",
		"label_obs_connect"  : "connectar",
		"label_obs_close"  : "cerrar",
		"label_obs_empty"  : "<p>No dejes ningun campo <b class=\"red-text\">vacio</b>!</p>",
		"label_obs_connected" : "<p>OBS <b class=\"green-text\">connectado</b></p>",
		"label_obs_check" : "<p><b class=\"orange-text\">Buscando</b> OBS</p>",
		"label_obs_check_again" : "<p><b class=\"blue-text\">Buscando</b> de nuevo OBS</p>",
		"tooltip_feedback_empty" : "No dejes ningun campo vacio",
		"tooltip_feedback_ok" : "Gracias por tu feedback, lo mas pronto posible antendere tus comentarios.",
		"tooltip_feedback_error" : "Lo siente, pero hubo un error y no se pudo mandar tu feedback en este momento.",
		"tooltip_config_save" : "<p>Configuracion <b class=\"green-text\">guardada</b>!</p>"
	}
};