var twitch = window.Twitch.ext;
twitch.onAuthorized(function(auth) {
    $.ajax({
        url: 'https://obss.amznws.access.ly/',
        type: 'POST',
        data: {
            'm': 'getconfig',
            'client': auth.clientId,
            'channel': auth.channelId,
            'user': auth.userId,
            'token': auth.token
        },
        dataType: 'json',
        success: function(res){
            if(typeof res.response["broadcaster:" + auth.channelId] != "undefined"){
                var tmp_content = res.response["broadcaster:" + auth.channelId].record.content;
                if(verifyJWT(tmp_content)){
                    tmp_content = decodeJWT(tmp_content);
                    $('#obs_url').val(tmp_content.url);
                    $('#obs_pass').val(tmp_content.password);
                }
            }
        }
    });
});

$(function() {
    $('.tooltiped').tooltip();

    $('ul.tabs').tabs();

    $('.btnSave').addClass('on').addClass('cursor').removeClass('hide').off('click').on('click', function(){
        if($('#obs_url').val() === '' || $('#obs_pass').val() === ''){
            Materialize.toast('<p>Dont left any field <b class="red-text">empty</b>!</p>', 4000);
            return;
        }

        var jwt = signJWT({"url": $('#obs_url').val(),"password": $('#obs_pass').val()});
        window.Twitch.ext.configuration.set("broadcaster", "0.1", jwt);
        Materialize.toast('<p>Configuration <b class="green-text">Saved</b>!</p>', 4000);
    });
});