var obs = new OBSWebSocket();
var streaming = false;

obs.onAuthenticationSuccess((res) => {
    Materialize.toast('<p>OBS <b class="green-text">connected</b></p>', 1500);
    $('.btnConnect').html('reload').addClass('reload');
    $('#scene_list').html('');
    $('.form_fields').fadeOut('fast');
    obs.getSceneList().then(data => {
        data.scenes.forEach(scene => {
            var tmp_a = "<a class='btn cursor scene_btn' data-name='" + scene.name + "' style='width:100%;'>" + scene.name + "</a>";
            $('#scene_list').append(tmp_a);
        });
        if(streaming){
            $('#scene_list').prepend("<a class='btn cursor btnStopStream red' style='width:100% !important;'>stop stream</a><br>");
        } else {
            $('#scene_list').prepend("<a class='btn cursor btnStartStream green' style='width:100% !important;'>start stream</a><br>");
        }

        $('.scene_btn').off('click').on('click', function(){
            var tmp_scene = $(this).attr("data-name");
            obs.setCurrentScene({
                'scene-name': tmp_scene
            });
            $('.scene_btn').removeClass('pink darken-1');
            $('.scene_btn[data-name="' + tmp_scene + '"]').addClass('pink darken-1');
        });

        $(document.body).off('click', '.btnStartStream').on('click', '.btnStartStream', function(){
            obs.startStreaming();
            $('.toast').remove();
            $(this).addClass('btnStopStream');
            $(this).removeClass('btnStartStream');

            $(this).addClass('red');
            $(this).removeClass('green');
            $(this).html('stop stream');
            Materialize.toast('<p>Streaming <b class="green-text">start</b></p>', 1500);
            streaming = true;
        });

        $(document.body).off('click', '.btnStopStream').on('click', '.btnStopStream', function(){
            obs.stopStreaming();
            $(this).removeClass('btnStopStream');
            $(this).addClass('btnStartStream');

            $(this).addClass('green');
            $(this).removeClass('red');
            $(this).html('start stream');
            Materialize.toast('<p>Streaming <b class="red-text">stop</b></p>', 1500);
            streaming = false;
        });

        obs.GetCurrentScene().then(data => {
            $('.scene_btn[data-name="' + data.name + '"]').addClass('pink darken-1');
        });

        obs.getStreamingStatus().then(data => {
            if(data.streaming){
                $('.btnStartStream').addClass('btnStopStream');
                $('.btnStartStream').removeClass('btnStartStream');

                $('.btnStopStream').addClass('red');
                $('.btnStopStream').removeClass('green');
                $('.btnStopStream').html('stop stream');
                streaming = true;
            } else {
                $('.btnStopStream').addClass('btnStartStream');
                $('.btnStopStream').removeClass('btnStopStream');

                $('.btnStartStream').addClass('green');
                $('.btnStartStream').removeClass('red');
                $('.btnStartStream').html('start stream');
                streaming = false;
            }
        });
    });

    var jwt = signJWT({"url": $('#obs_url').val(),"password": $('#obs_pass').val()});
    window.Twitch.ext.configuration.set("broadcaster", "0.1", jwt);
});

obs.onAuthenticationFailure(() => {
    Materialize.toast('<p>Check your credential and try again <b class="red-text">error</b></p>', 1500);
    $('.btnConnect').html('connect connection').removeClass('reload');
    $('#scene_list').html('');
    $('.form_fields').fadeIn('fast');
});

var twitch = window.Twitch.ext;

twitch.onAuthorized(function(auth) {
    if(twitch.viewer.role == "broadcaster"){
        $.ajax({
            url: 'https://obss.amznws.access.ly/',
            type: 'POST',
            data: {
                'm': 'getconfig',
                'client': auth.clientId,
                'channel': auth.channelId,
                'user': auth.userId,
                'token': auth.token
            },
            dataType: 'json',
            success: function(res){
                if(typeof res.response["broadcaster:" + auth.channelId] != "undefined"){
                    var tmp_content = res.response["broadcaster:" + auth.channelId].record.content;
                    if(verifyJWT(tmp_content)){
                        tmp_content = decodeJWT(tmp_content);
                        $('#obs_url').val(tmp_content.url);
                        $('#obs_pass').val(tmp_content.password);
                        $('.btnConnect').trigger('click');
                    }
                }
            }
        });
    } else {
        $('.form_fields, .btnConnect').addClass('hide');
    }
});

twitch.onContext(function(context, attr) {
    if(context.mode == "viewer"){
        $('html,body').addClass('overlay-font-s');
        $('.btn, .btn-large').addClass('overlay-btns');
    }
});
$(function() {
    $('.btnConnect').addClass('on').addClass('cursor').removeClass('hide').off('click').on('click', function(){
        if($(this).hasClass('reload')) {
            $('.btnConnect').html('connect connection').removeClass('reload');
            $('#scene_list').html('');
            obs.disconnect();
            $('.form_fields').fadeIn('fast');
            $('.btnConnect').trigger('click');
        } else {
            if($('#obs_url').val() === '' || $('#obs_pass').val() === ''){
                Materialize.toast('<p>Dont left any field <b class="red-text">empty</b>!</p>', 4000);
                return;
            }
            obs.connect({
                address: $('#obs_url').val(),
                password: $('#obs_pass').val()
            });
        }
    });

    $('.tooltiped').tooltip();
});